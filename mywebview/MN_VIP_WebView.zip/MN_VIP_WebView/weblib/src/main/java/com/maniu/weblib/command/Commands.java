package com.maniu.weblib.command;


import com.maniu.weblib.interfaces.Command;

import java.util.HashMap;

/**
 * 所有命令对象的基类
 * 比如  我要处理的命令有哪些
 */
public abstract class Commands {
    //是对每一种命令的集合
    private HashMap<String, Command> commands;

    abstract int getCommandLevel();

    public HashMap<String, Command> getCommands() {
        return commands;
    }

    public Commands() {
        commands = new HashMap<>();
    }

    protected void registerCommand(Command command) {
        commands.put(command.name(), command);
    }
}


