package com.maniu.weblib.interfaces;

public interface Action<T> {
    void call(T t);
}

